from django.apps import AppConfig


class TweetConfig(AppConfig):
    name = 'tweet'
